//
//  RestauranteDetalles.swift
//  FoodTracker
//
//  Created by Manuel Gallego Chinchilla on 10/4/19.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import Foundation
